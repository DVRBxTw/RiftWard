@echo off
cd /d "%~dp0"
py -3 server\run_server.py
pause
